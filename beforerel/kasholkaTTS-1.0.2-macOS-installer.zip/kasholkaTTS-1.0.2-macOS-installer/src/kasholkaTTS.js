/* kasholkaTTS 1.0.2 — macOS 12+, JavaScript for Automation / AppKit.
 * Compiled as a stay-open applet by the installer using macOS osacompile.
 * No browser, network, third-party runtime, or automation of other apps.
 */
ObjC.import('Cocoa');

var VERSION = '1.0.2';
var ui = {};
var controller = null;
var synth = null;
var voices = [];
var active = false;
var paused = false;
var pitchAvailable = false;
var defaultPitch = 48;
var defaults = null;

function unwrap(value, fallback) {
    if (!value || value.isNil && value.isNil()) return fallback;
    var result = ObjC.unwrap(value);
    return result === undefined || result === null ? fallback : result;
}

function clamp(value, low, high, fallback) {
    value = Number(value);
    return isFinite(value) ? Math.max(low, Math.min(high, value)) : fallback;
}

function textToRead(text, location, length) {
    // NSString/NSTextView ranges and JS strings both count UTF-16 code units.
    return length > 0 ? text.substr(location, length) : text;
}

function status(message) {
    if (ui.status) ui.status.stringValue = $(message);
}

function alertUser(title, message) {
    var alert = $.NSAlert.alloc.init;
    alert.messageText = $(title);
    alert.informativeText = $(message);
    alert.addButtonWithTitle($('OK'));
    alert.runModal;
}

function guarded(action) {
    return function () {
        try { action(); }
        catch (error) {
            status('Ошибка. Попробуйте другой голос или перезапустите приложение.');
            alertUser('kasholkaTTS', String(error));
        }
    };
}

function updateControls() {
    var ready = !!synth && voices.length > 0;
    ui.play.enabled = ready && !active;
    ui.pause.enabled = active;
    ui.pause.title = $(paused ? 'Продолжить' : 'Пауза');
    ui.stop.enabled = active;
    ui.voice.enabled = !active && voices.length > 0;
    ui.refresh.enabled = !active;
    ui.rate.enabled = ready && !active;
    ui.pitch.enabled = ready && !active && pitchAvailable;
    ui.reset.enabled = ready && !active;
    ui.open.enabled = !active;
    ui.editor.editable = !active;
}

function pitchKey() {
    return 'pitch.' + voices[Number(ui.voice.indexOfSelectedItem)].id;
}

function applyRate() {
    var rate = Math.round(clamp(ui.rate.doubleValue, 80, 400, 180));
    ui.rate.doubleValue = rate;
    ui.rateValue.stringValue = $(rate + ' слов/мин');
    if (synth) synth.rate = rate;
    defaults.setDoubleForKey(rate, $('rate'));
}

function disablePitch() {
    pitchAvailable = false;
    ui.pitch.enabled = false;
    ui.pitchValue.stringValue = $('—');
    ui.pitchHint.stringValue = $('Этот голос не предоставляет управление высотой. Скорость доступна.');
}

function applyPitch() {
    if (!pitchAvailable || !synth) return;
    var value = clamp(ui.pitch.doubleValue, ui.pitch.minValue, ui.pitch.maxValue, defaultPitch);
    var error = Ref();
    var ok = synth.setObjectForPropertyError($(value), $.NSSpeechPitchBaseProperty, error);
    if (!ok) { disablePitch(); return; }
    ui.pitchValue.stringValue = $(value.toFixed(1));
    defaults.setDoubleForKey(value, $(pitchKey()));
}

function inspectPitch() {
    pitchAvailable = false;
    try {
        var error = Ref();
        var base = synth.objectForPropertyError($.NSSpeechPitchBaseProperty, error);
        var value = Number(unwrap(base, NaN));
        if (!isFinite(value) || value <= 0) { disablePitch(); return; }
        defaultPitch = value;
        // Ask the actual selected voice whether the property is writable.
        if (!synth.setObjectForPropertyError($(value), $.NSSpeechPitchBaseProperty, Ref())) {
            disablePitch(); return;
        }
        pitchAvailable = true;
        ui.pitch.minValue = Math.max(1, value - 12);
        ui.pitch.maxValue = value + 12;
        var saved = defaults.objectForKey($(pitchKey()));
        ui.pitch.doubleValue = clamp(unwrap(saved, value), ui.pitch.minValue, ui.pitch.maxValue, value);
        ui.pitchHint.stringValue = $('Высота: ниже ← → выше. Сила эффекта зависит от системного голоса.');
        applyPitch();
    } catch (error) { disablePitch(); }
}

function selectVoice() {
    if (active || !voices.length) return;
    var item = voices[Number(ui.voice.indexOfSelectedItem)];
    if (!item) return;
    // A new synthesizer restores the voice's real baseline pitch before probing.
    if (synth) { synth.delegate = null; synth.stopSpeaking; }
    synth = $.NSSpeechSynthesizer.alloc.initWithVoice($(item.id));
    if (!synth || synth.isNil()) {
        synth = null;
        disablePitch();
        status('Голос недоступен. Выберите другой или обновите список.');
        updateControls();
        return;
    }
    synth.delegate = controller;
    defaults.setObjectForKey($(item.id), $('voice'));
    applyRate();
    inspectPitch();
    status('Готово • ' + item.name);
    updateControls();
}

function refreshVoices() {
    if (active) return;
    var preferred = unwrap(defaults.stringForKey($('voice')), '');
    if (!preferred) preferred = unwrap($.NSSpeechSynthesizer.defaultVoice, '');
    var available = $.NSSpeechSynthesizer.availableVoices;
    voices = [];
    for (var i = 0; i < Number(available.count); i++) {
        var id = available.objectAtIndex(i);
        var attrs = $.NSSpeechSynthesizer.attributesForVoice(id);
        voices.push({
            id: unwrap(id, ''),
            name: unwrap(attrs.objectForKey($.NSVoiceName), unwrap(id, 'Голос')),
            locale: unwrap(attrs.objectForKey($.NSVoiceLocaleIdentifier), '')
        });
    }
    voices.sort(function (a, b) {
        return (a.locale + a.name + a.id).localeCompare(b.locale + b.name + b.id);
    });
    ui.voice.removeAllItems;
    var selected = 0;
    voices.forEach(function (voice, index) {
        // NSPopUpButton coalesces duplicate titles; keep every voice selectable.
        ui.voice.addItemWithTitle($((index + 1) + '. ' + voice.name + '  ·  ' + voice.locale));
        if (voice.id === preferred) selected = index;
    });
    if (voices.length) {
        ui.voice.selectItemAtIndex(selected);
        selectVoice();
    } else {
        if (synth) { synth.delegate = null; synth.stopSpeaking; }
        synth = null;
        disablePitch();
        status('Нет доступных голосов. Добавьте голос в настройках macOS и нажмите «Обновить».');
        updateControls();
    }
}

function play() {
    if (active || !synth) return;
    var range = ui.editor.selectedRange;
    var text = textToRead(unwrap(ui.editor.string, ''), Number(range.location), Number(range.length));
    if (!text.trim()) { status('Введите текст или выделите фрагмент для чтения.'); return; }
    applyRate();
    applyPitch();
    active = true;
    paused = false;
    status(range.length > 0 ? 'Читаю выделенный фрагмент…' : 'Читаю текст…');
    updateControls();
    var started;
    try { started = synth.startSpeakingString($(text)); }
    catch (error) {
        active = false;
        updateControls();
        throw error;
    }
    if (!started) {
        active = false;
        status('Не удалось начать чтение. Попробуйте другой голос.');
        updateControls();
    }
}

function pauseOrResume() {
    if (!active || !synth) return;
    if (paused) {
        synth.continueSpeaking;
        paused = false;
        status('Читаю текст…');
    } else {
        synth.pauseSpeakingAtBoundary($.NSSpeechImmediateBoundary);
        paused = true;
        status('Пауза');
    }
    updateControls();
}

function stop() {
    // Detach before stopping: late completion callbacks must not finish a new run.
    active = false;
    paused = false;
    if (synth) { synth.delegate = null; synth.stopSpeaking; }
    selectVoice();
    status('Остановлено');
    updateControls();
}

function reset() {
    if (active) return;
    ui.rate.doubleValue = 180;
    applyRate();
    if (pitchAvailable) { ui.pitch.doubleValue = defaultPitch; applyPitch(); }
    status('Параметры голоса сброшены');
}

function openText() {
    var panel = $.NSOpenPanel.openPanel;
    panel.title = $('Открыть текст');
    panel.allowedFileTypes = $(['txt', 'text', 'md']);
    panel.allowsMultipleSelection = false;
    panel.canChooseDirectories = false;
    if (panel.runModal !== $.NSModalResponseOK) return;
    var error = Ref();
    var text = $.NSString.stringWithContentsOfURLUsedEncodingError(panel.URL, Ref(), error);
    if (!text || text.isNil()) {
        alertUser('Не удалось открыть файл', 'Сохраните его как обычный текст UTF-8 или UTF-16 и попробуйте снова.');
        return;
    }
    ui.editor.string = text;
    status('Файл открыт. Нажмите «Читать».');
}

function registerController() {
    ObjC.registerSubclass({
        name: 'KasholkaController',
        superclass: 'NSObject',
        // Do not resolve delegate protocols through JXA: their metadata may be
        // unavailable on Monterey ("protocol does not exist"). Cocoa dispatches
        // these optional callbacks by selector. Explicit types below provide
        // the signatures without requiring protocol lookup by the bridge.
        methods: {
            'play:': { types: ['void', ['id']], implementation: guarded(play) },
            'pause:': { types: ['void', ['id']], implementation: guarded(pauseOrResume) },
            'stop:': { types: ['void', ['id']], implementation: guarded(stop) },
            'voice:': { types: ['void', ['id']], implementation: guarded(selectVoice) },
            'refresh:': { types: ['void', ['id']], implementation: guarded(refreshVoices) },
            'rate:': { types: ['void', ['id']], implementation: guarded(applyRate) },
            'pitch:': { types: ['void', ['id']], implementation: guarded(applyPitch) },
            'reset:': { types: ['void', ['id']], implementation: guarded(reset) },
            'openText:': { types: ['void', ['id']], implementation: guarded(openText) },
            'speechSynthesizer:didFinishSpeaking:': {
                types: ['void', ['id', 'bool']],
                implementation: function (sender, finished) {
                    if (!synth || !sender.isEqual(synth) || !active) return;
                    active = false;
                    paused = false;
                    status(finished ? 'Прочитано' : 'Чтение прервано');
                    updateControls();
                }
            },
            'windowWillClose:': {
                types: ['void', ['id']],
                implementation: function () {
                    if (synth) { synth.delegate = null; synth.stopSpeaking; }
                    $.NSApplication.sharedApplication.terminate(null);
                }
            }
        }
    });
    controller = $.KasholkaController.alloc.init;
}

function addLabel(text, x, y, w, size, secondary, top) {
    var label = $.NSTextField.labelWithString($(text));
    label.frame = $.NSMakeRect(x, y, w, 24);
    label.font = $.NSFont.systemFontOfSize(size || 13);
    label.textColor = secondary ? $.NSColor.secondaryLabelColor : $.NSColor.labelColor;
    label.autoresizingMask = top ? $.NSViewMinYMargin : 0;
    ui.content.addSubview(label);
    return label;
}

function addButton(title, selector, x, y, w, top) {
    var button = $.NSButton.alloc.initWithFrame($.NSMakeRect(x, y, w, 34));
    button.title = $(title);
    button.bezelStyle = $.NSBezelStyleRounded;
    button.target = controller;
    button.action = selector;
    button.autoresizingMask = top ? $.NSViewMinYMargin : 0;
    ui.content.addSubview(button);
    return button;
}

function addSlider(min, max, value, selector, x, y, w) {
    var slider = $.NSSlider.alloc.initWithFrame($.NSMakeRect(x, y, w, 24));
    slider.minValue = min;
    slider.maxValue = max;
    slider.doubleValue = value;
    slider.continuous = true;
    slider.target = controller;
    slider.action = selector;
    slider.autoresizingMask = $.NSViewMinYMargin;
    ui.content.addSubview(slider);
    return slider;
}

function installMenus() {
    var menu = $.NSMenu.alloc.init;
    var appItem = $.NSMenuItem.alloc.init;
    var appMenu = $.NSMenu.alloc.initWithTitle($('kasholkaTTS'));
    appMenu.addItemWithTitleActionKeyEquivalent($('О kasholkaTTS'), 'orderFrontStandardAboutPanel:', $(''));
    appMenu.addItem($.NSMenuItem.separatorItem);
    appMenu.addItemWithTitleActionKeyEquivalent($('Скрыть kasholkaTTS'), 'hide:', $('h'));
    appMenu.addItemWithTitleActionKeyEquivalent($('Завершить kasholkaTTS'), 'terminate:', $('q'));
    appItem.submenu = appMenu;
    menu.addItem(appItem);
    var editItem = $.NSMenuItem.alloc.init;
    var editMenu = $.NSMenu.alloc.initWithTitle($('Правка'));
    [['Отменить', 'undo:', 'z'], ['Вырезать', 'cut:', 'x'], ['Копировать', 'copy:', 'c'],
        ['Вставить', 'paste:', 'v'], ['Выделить всё', 'selectAll:', 'a']].forEach(function (entry) {
        editMenu.addItemWithTitleActionKeyEquivalent($(entry[0]), entry[1], $(entry[2]));
    });
    editItem.submenu = editMenu;
    menu.addItem(editItem);
    $.NSApplication.sharedApplication.mainMenu = menu;
}

function run() {
    if (ui.window) { ui.window.makeKeyAndOrderFront(null); return; }
    defaults = $.NSUserDefaults.standardUserDefaults;
    registerController();
    var app = $.NSApplication.sharedApplication;
    app.setActivationPolicy($.NSApplicationActivationPolicyRegular);
    var style = $.NSWindowStyleMaskTitled | $.NSWindowStyleMaskClosable |
        $.NSWindowStyleMaskMiniaturizable | $.NSWindowStyleMaskResizable;
    ui.window = $.NSWindow.alloc.initWithContentRectStyleMaskBackingDefer(
        $.NSMakeRect(0, 0, 900, 720), style, $.NSBackingStoreBuffered, false);
    ui.window.title = $('kasholkaTTS');
    ui.window.contentMinSize = $.NSMakeSize(900, 720);
    ui.window.releasedWhenClosed = false;
    ui.window.delegate = controller;
    ui.content = ui.window.contentView;

    var title = addLabel('kasholkaTTS', 28, 663, 500, 28, false, true);
    title.frame = $.NSMakeRect(28, 655, 500, 40);
    title.font = $.NSFont.boldSystemFontOfSize(28);
    addLabel('Текст становится голосом. Локально, на вашем Mac.', 30, 622, 700, 14, true, true);
    addLabel('Голос', 30, 578, 70, 14, false, true);
    ui.voice = $.NSPopUpButton.alloc.initWithFramePullsDown($.NSMakeRect(100, 574, 640, 32), false);
    ui.voice.target = controller;
    ui.voice.action = 'voice:';
    ui.voice.autoresizingMask = $.NSViewMinYMargin | $.NSViewWidthSizable;
    ui.content.addSubview(ui.voice);
    ui.refresh = addButton('Обновить', 'refresh:', 755, 573, 115, true);
    ui.refresh.autoresizingMask = $.NSViewMinYMargin | $.NSViewMinXMargin;

    addLabel('Скорость', 30, 538, 90, 13, false, true);
    ui.rate = addSlider(80, 400, clamp(unwrap(defaults.objectForKey($('rate')), 180), 80, 400, 180),
        'rate:', 116, 535, 200);
    ui.rateValue = addLabel('', 328, 538, 125, 13, true, true);
    addLabel('Высота', 477, 538, 70, 13, false, true);
    ui.pitch = addSlider(36, 60, 48, 'pitch:', 547, 535, 220);
    ui.pitchValue = addLabel('', 784, 538, 70, 13, true, true);
    ui.pitchHint = addLabel('', 30, 500, 840, 12, true, true);
    addLabel('ВАШ ТЕКСТ', 30, 460, 300, 12, true, true);
    ui.open = addButton('Открыть .txt…', 'openText:', 720, 453, 150, true);
    ui.open.autoresizingMask = $.NSViewMinYMargin | $.NSViewMinXMargin;

    var scroll = $.NSScrollView.alloc.initWithFrame($.NSMakeRect(30, 163, 840, 282));
    scroll.borderType = $.NSBezelBorder;
    scroll.hasVerticalScroller = true;
    scroll.autoresizingMask = $.NSViewWidthSizable | $.NSViewHeightSizable;
    ui.editor = $.NSTextView.alloc.initWithFrame($.NSMakeRect(0, 0, 820, 282));
    ui.editor.richText = false;
    ui.editor.allowsUndo = true;
    ui.editor.font = $.NSFont.systemFontOfSize(18);
    ui.editor.textColor = $.NSColor.textColor;
    ui.editor.backgroundColor = $.NSColor.textBackgroundColor;
    ui.editor.textContainerInset = $.NSMakeSize(16, 16);
    ui.editor.verticallyResizable = true;
    ui.editor.horizontallyResizable = false;
    ui.editor.minSize = $.NSMakeSize(0, 282);
    ui.editor.maxSize = $.NSMakeSize(1000000, 1000000);
    ui.editor.autoresizingMask = $.NSViewWidthSizable;
    ui.editor.textContainer.containerSize = $.NSMakeSize(820, 1000000);
    ui.editor.textContainer.widthTracksTextView = true;
    scroll.documentView = ui.editor;
    ui.content.addSubview(scroll);

    ui.play = addButton('Читать', 'play:', 25, 108, 130, false);
    ui.pause = addButton('Пауза', 'pause:', 164, 108, 140, false);
    ui.stop = addButton('Стоп', 'stop:', 313, 108, 110, false);
    ui.reset = addButton('Сброс параметров', 'reset:', 680, 108, 195, false);
    ui.reset.autoresizingMask = $.NSViewMinXMargin;
    ui.status = addLabel('Загрузка голосов…', 30, 69, 840, 13, false, false);
    ui.status.autoresizingMask = $.NSViewWidthSizable;
    addLabel('Выделите фрагмент, чтобы прочитать только его. Параметры меняются после остановки.',
        30, 34, 840, 12, true, false);
    installMenus();
    refreshVoices();
    ui.window.center;
    ui.window.makeKeyAndOrderFront(null);
    ui.window.makeFirstResponder(ui.editor);
    app.activateIgnoringOtherApps(true);
}

function reopen() {
    if (ui.window) ui.window.makeKeyAndOrderFront(null);
}

function idle() { return 30; }

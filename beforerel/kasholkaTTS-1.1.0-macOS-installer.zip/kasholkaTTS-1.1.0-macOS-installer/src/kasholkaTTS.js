/* kasholkaTTS 1.1.0 — macOS 12+, JavaScript for Automation / AppKit.
 * Compiled as a stay-open applet by the installer using macOS osacompile.
 * No browser, network, third-party runtime, or automation of other apps.
 */
ObjC.import('Cocoa');
ObjC.import('AVFoundation');

var VERSION = '1.1.0';
var ui = {};
var controller = null;
var synth = null;
var voices = [];
var active = false;
var paused = false;
var pitchAvailable = false;
var defaultPitch = 48;
var defaults = null;
var engine = 'ns';
var currentUtterance = null;
var scale = 1;
var about = {};

function stopSynth() {
    currentUtterance = null;
    if (!synth) return;
    synth.delegate = null;
    if (engine === 'av') synth.stopSpeakingAtBoundary($.AVSpeechBoundaryImmediate);
    else synth.stopSpeaking;
}

function finishAV(sender, utterance, finished) {
    if (!synth || !sender.isEqual(synth) || !active || !currentUtterance ||
        !utterance.isEqual(currentUtterance)) return;
    active = false;
    paused = false;
    currentUtterance = null;
    status(finished ? 'Прочитано' : 'Чтение прервано');
    updateControls();
}

function unwrap(value, fallback) {
    if (!value || value.isNil && value.isNil()) return fallback;
    var result = ObjC.unwrap(value);
    return result === undefined || result === null ? fallback : result;
}

function clamp(value, low, high, fallback) {
    value = Number(value);
    return isFinite(value) ? Math.max(low, Math.min(high, value)) : fallback;
}

function textToRead(text, location, length) {
    // NSString/NSTextView ranges and JS strings both count UTF-16 code units.
    return length > 0 ? text.substr(location, length) : text;
}

function status(message) {
    if (ui.status) ui.status.stringValue = $(message);
}

function alertUser(title, message) {
    var alert = $.NSAlert.alloc.init;
    alert.messageText = $(title);
    alert.informativeText = $(message);
    alert.addButtonWithTitle($('OK'));
    alert.runModal;
}

function guarded(action) {
    return function () {
        try { action(); }
        catch (error) {
            status('Ошибка. Попробуйте другой голос или перезапустите приложение.');
            alertUser('kasholkaTTS', String(error));
        }
    };
}

function updateControls() {
    var ready = !!synth && voices.length > 0;
    ui.play.enabled = ready && !active;
    ui.pause.enabled = active;
    ui.pause.title = $(paused ? 'Продолжить' : 'Пауза');
    ui.stop.enabled = active;
    ui.voice.enabled = !active && voices.length > 0;
    ui.refresh.enabled = !active;
    ui.rate.enabled = ready && !active;
    ui.pitch.enabled = ready && !active && pitchAvailable;
    ui.reset.enabled = ready && !active;
    ui.open.enabled = !active;
    ui.editor.editable = !active;
}

function pitchKey() {
    return (engine === 'av' ? 'pitch.av.' : 'pitch.') + voices[Number(ui.voice.indexOfSelectedItem)].id;
}

function applyRate() {
    var rate = Math.round(clamp(ui.rate.doubleValue, 80, engine === 'av' ? 360 : 400, 180));
    ui.rate.doubleValue = rate;
    ui.rateValue.stringValue = $(engine === 'av' ? (rate / 180).toFixed(2) + '×' : rate + ' сл/мин');
    if (synth && engine === 'ns') synth.rate = rate;
    defaults.setDoubleForKey(rate, $('rate'));
}

function disablePitch() {
    pitchAvailable = false;
    ui.pitch.enabled = false;
    ui.pitchValue.stringValue = $('—');
    ui.pitch.toolTip = $('Этот голос не предоставляет управление высотой.');
}

function applyPitch() {
    if (!pitchAvailable || !synth) return;
    var value = clamp(ui.pitch.doubleValue, ui.pitch.minValue, ui.pitch.maxValue, defaultPitch);
    if (engine === 'av') {
        ui.pitchValue.stringValue = $(value.toFixed(2) + '×');
        defaults.setDoubleForKey(value, $(pitchKey()));
        return;
    }
    var error = Ref();
    var ok = synth.setObjectForPropertyError($(value), $.NSSpeechPitchBaseProperty, error);
    if (!ok) { disablePitch(); return; }
    ui.pitchValue.stringValue = $(value.toFixed(1));
    defaults.setDoubleForKey(value, $(pitchKey()));
}

function inspectPitch() {
    pitchAvailable = false;
    if (engine === 'av') {
        pitchAvailable = true;
        defaultPitch = 1;
        ui.pitch.minValue = 0.5;
        ui.pitch.maxValue = 2;
        ui.pitch.doubleValue = clamp(unwrap(defaults.objectForKey($(pitchKey())), 1), 0.5, 2, 1);
        ui.pitch.toolTip = $('Высота: 0.5×–2×. Эффект зависит от голоса.');
        applyPitch();
        return;
    }
    try {
        var error = Ref();
        var base = synth.objectForPropertyError($.NSSpeechPitchBaseProperty, error);
        var value = Number(unwrap(base, NaN));
        if (!isFinite(value) || value <= 0) { disablePitch(); return; }
        defaultPitch = value;
        // Ask the actual selected voice whether the property is writable.
        if (!synth.setObjectForPropertyError($(value), $.NSSpeechPitchBaseProperty, Ref())) {
            disablePitch(); return;
        }
        pitchAvailable = true;
        ui.pitch.minValue = Math.max(1, value - 12);
        ui.pitch.maxValue = value + 12;
        var saved = defaults.objectForKey($(pitchKey()));
        ui.pitch.doubleValue = clamp(unwrap(saved, value), ui.pitch.minValue, ui.pitch.maxValue, value);
        ui.pitch.toolTip = $('Ниже ← → выше. Эффект зависит от голоса.');
        applyPitch();
    } catch (error) { disablePitch(); }
}

function selectVoice() {
    if (active || !voices.length) return;
    var item = voices[Number(ui.voice.indexOfSelectedItem)];
    if (!item) return;
    // A new synthesizer restores the voice's real baseline pitch before probing.
    stopSynth();
    engine = item.engine || 'ns';
    synth = engine === 'av' ? $.AVSpeechSynthesizer.alloc.init :
        $.NSSpeechSynthesizer.alloc.initWithVoice($(item.id));
    if (!synth || synth.isNil()) {
        synth = null;
        disablePitch();
        status('Голос недоступен. Выберите другой или обновите список.');
        updateControls();
        return;
    }
    synth.delegate = controller;
    ui.rate.maxValue = engine === 'av' ? 360 : 400;
    defaults.setObjectForKey($((engine === 'av' ? 'av:' : '') + item.id), $('voice'));
    applyRate();
    inspectPitch();
    status('Готово • ' + item.name);
    updateControls();
}

function refreshVoices() {
    if (active) return;
    var preferred = unwrap(defaults.stringForKey($('voice')), '');
    if (!preferred) preferred = unwrap($.NSSpeechSynthesizer.defaultVoice, '');
    var available = $.NSSpeechSynthesizer.availableVoices;
    voices = [];
    for (var i = 0; i < Number(available.count); i++) {
        var id = available.objectAtIndex(i);
        var attrs = $.NSSpeechSynthesizer.attributesForVoice(id);
        voices.push({
            engine: 'ns',
            id: unwrap(id, ''),
            name: unwrap(attrs.objectForKey($.NSVoiceName), unwrap(id, 'Голос')),
            locale: unwrap(attrs.objectForKey($.NSVoiceLocaleIdentifier), '')
        });
    }
    // Public AVFoundation API exposes additional voices on some Macs, including
    // Siri when the OS makes them available. Never fabricate hidden identifiers.
    var avFailed = false;
    try {
        var modern = $.AVSpeechSynthesisVoice.speechVoices;
        var seen = {};
        voices.forEach(function (voice) { seen[voice.id] = true; });
        for (var j = 0; j < Number(modern.count); j++) {
            var nativeVoice = modern.objectAtIndex(j);
            var identifier = unwrap(nativeVoice.identifier, '');
            if (!identifier || seen[identifier]) continue;
            seen[identifier] = true;
            voices.push({ id: identifier, engine: 'av',
                name: unwrap(nativeVoice.name, identifier),
                locale: unwrap(nativeVoice.language, '') });
        }
    } catch (error) { avFailed = true; }
    voices.sort(function (a, b) {
        return (a.locale + a.name + a.id).localeCompare(b.locale + b.name + b.id);
    });
    ui.voice.removeAllItems;
    var selected = 0;
    voices.forEach(function (voice, index) {
        // NSPopUpButton coalesces duplicate titles; keep every voice selectable.
        var siri = voice.id.indexOf('com.apple.siri.') === 0 ? ' · Siri' : '';
        ui.voice.addItemWithTitle($((index + 1) + '. ' + voice.name + ' · ' + voice.locale + siri));
        if ((voice.engine === 'av' ? 'av:' : '') + voice.id === preferred) selected = index;
    });
    if (voices.length) {
        ui.voice.selectItemAtIndex(selected);
        selectVoice();
    } else {
        stopSynth();
        synth = null;
        disablePitch();
        status('Нет доступных голосов. Добавьте голос в настройках macOS и нажмите «Обновить».');
        updateControls();
    }
    if (avFailed) status('Дополнительные голоса недоступны. Обычные голоса можно использовать.');
}

function play() {
    if (active || !synth) return;
    var range = ui.editor.selectedRange;
    var text = textToRead(unwrap(ui.editor.string, ''), Number(range.location), Number(range.length));
    if (!text.trim()) { status('Введите текст или выделите фрагмент для чтения.'); return; }
    applyRate();
    applyPitch();
    active = true;
    paused = false;
    status(range.length > 0 ? 'Читаю выделенный фрагмент…' : 'Читаю текст…');
    updateControls();
    var started;
    try {
        if (engine === 'av') {
            var item = voices[Number(ui.voice.indexOfSelectedItem)];
            var avVoice = $.AVSpeechSynthesisVoice.voiceWithIdentifier($(item.id));
            if (!avVoice || avVoice.isNil()) throw new Error('Выбранный голос больше недоступен. Обновите список.');
            currentUtterance = $.AVSpeechUtterance.speechUtteranceWithString($(text));
            currentUtterance.voice = avVoice;
            currentUtterance.rate = clamp(Number(ui.rate.doubleValue) / 180 * 0.5, 0.1, 1, 0.5);
            currentUtterance.pitchMultiplier = clamp(ui.pitch.doubleValue, 0.5, 2, 1);
            synth.speakUtterance(currentUtterance);
            started = true;
        } else started = synth.startSpeakingString($(text));
    }
    catch (error) {
        active = false;
        currentUtterance = null;
        updateControls();
        throw error;
    }
    if (!started) {
        active = false;
        status('Не удалось начать чтение. Попробуйте другой голос.');
        updateControls();
    }
}

function pauseOrResume() {
    if (!active || !synth) return;
    if (paused) {
        var resumed = synth.continueSpeaking;
        if (engine === 'av' && !resumed) return;
        paused = false;
        status('Читаю текст…');
    } else {
        var didPause = synth.pauseSpeakingAtBoundary(engine === 'av' ? $.AVSpeechBoundaryImmediate : $.NSSpeechImmediateBoundary);
        if (engine === 'av' && !didPause) return;
        paused = true;
        status('Пауза');
    }
    updateControls();
}

function stop() {
    // Detach before stopping: late completion callbacks must not finish a new run.
    active = false;
    paused = false;
    stopSynth();
    selectVoice();
    status('Остановлено');
    updateControls();
}

function reset() {
    if (active) return;
    ui.rate.doubleValue = 180;
    applyRate();
    if (pitchAvailable) { ui.pitch.doubleValue = defaultPitch; applyPitch(); }
    status('Параметры голоса сброшены');
}

function openText() {
    var panel = $.NSOpenPanel.openPanel;
    panel.title = $('Открыть текст');
    panel.allowedFileTypes = $(['txt', 'text', 'md']);
    panel.allowsMultipleSelection = false;
    panel.canChooseDirectories = false;
    if (panel.runModal !== $.NSModalResponseOK) return;
    var error = Ref();
    var text = $.NSString.stringWithContentsOfURLUsedEncodingError(panel.URL, Ref(), error);
    if (!text || text.isNil()) {
        alertUser('Не удалось открыть файл', 'Сохраните его как обычный текст UTF-8 или UTF-16 и попробуйте снова.');
        return;
    }
    ui.editor.string = text;
    status('Файл открыт. Нажмите «Читать».');
}

function registerController() {
    ObjC.registerSubclass({
        name: 'KasholkaController',
        superclass: 'NSObject',
        // Do not resolve delegate protocols through JXA: their metadata may be
        // unavailable on Monterey ("protocol does not exist"). Cocoa dispatches
        // these optional callbacks by selector. Explicit types below provide
        // the signatures without requiring protocol lookup by the bridge.
        methods: {
            'play:': { types: ['void', ['id']], implementation: guarded(play) },
            'pause:': { types: ['void', ['id']], implementation: guarded(pauseOrResume) },
            'stop:': { types: ['void', ['id']], implementation: guarded(stop) },
            'voice:': { types: ['void', ['id']], implementation: guarded(selectVoice) },
            'refresh:': { types: ['void', ['id']], implementation: guarded(refreshVoices) },
            'rate:': { types: ['void', ['id']], implementation: guarded(applyRate) },
            'pitch:': { types: ['void', ['id']], implementation: guarded(applyPitch) },
            'reset:': { types: ['void', ['id']], implementation: guarded(reset) },
            'openText:': { types: ['void', ['id']], implementation: guarded(openText) },
            'about:': { types: ['void', ['id']], implementation: guarded(showAbout) },
            'zoomIn:': { types: ['void', ['id']], implementation: guarded(function () { setScale(scale + 0.1); }) },
            'zoomOut:': { types: ['void', ['id']], implementation: guarded(function () { setScale(scale - 0.1); }) },
            'zoomReset:': { types: ['void', ['id']], implementation: guarded(function () { setScale(1); }) },
            'speechSynthesizer:didFinishSpeechUtterance:': {
                types: ['void', ['id', 'id']], implementation: function (sender, utterance) { finishAV(sender, utterance, true); }
            },
            'speechSynthesizer:didCancelSpeechUtterance:': {
                types: ['void', ['id', 'id']], implementation: function (sender, utterance) { finishAV(sender, utterance, false); }
            },
            'speechSynthesizer:didFinishSpeaking:': {
                types: ['void', ['id', 'bool']],
                implementation: function (sender, finished) {
                    if (!synth || !sender.isEqual(synth) || !active) return;
                    active = false;
                    paused = false;
                    status(finished ? 'Прочитано' : 'Чтение прервано');
                    updateControls();
                }
            },
            'windowWillClose:': {
                types: ['void', ['id']],
                implementation: function (notification) {
                    if (notification && about.window && notification.object.isEqual(about.window)) {
                        if (about.player) about.player.pause;
                        return;
                    }
                    if (about.player) about.player.pause;
                    stopSynth();
                    $.NSApplication.sharedApplication.terminate(null);
                }
            },
            'windowDidResize:': {
                types: ['void', ['id']], implementation: function (notification) {
                    if (ui.window && notification.object.isEqual(ui.window)) layoutUI();
                }
            }
        }
    });
    controller = $.KasholkaController.alloc.init;
}

function addLabel(text, size, secondary) {
    var label = $.NSTextField.labelWithString($(text));
    label.font = $.NSFont.systemFontOfSize(size || 13);
    label.textColor = secondary ? $.NSColor.secondaryLabelColor : $.NSColor.labelColor;
    ui.content.addSubview(label);
    return label;
}

function addButton(title, selector) {
    var button = $.NSButton.alloc.initWithFrame($.NSMakeRect(0, 0, 100, 32));
    button.title = $(title);
    button.bezelStyle = $.NSBezelStyleRounded;
    button.target = controller;
    button.action = selector;
    ui.content.addSubview(button);
    return button;
}

function addSlider(min, max, value, selector) {
    var slider = $.NSSlider.alloc.initWithFrame($.NSMakeRect(0, 0, 100, 24));
    slider.minValue = min;
    slider.maxValue = max;
    slider.doubleValue = value;
    slider.continuous = true;
    slider.target = controller;
    slider.action = selector;
    ui.content.addSubview(slider);
    return slider;
}

function layoutFrames(width, height, factor) {
    var w = width / factor, h = height / factor, half = w / 2;
    var frames = {
        voiceLabel: [16, h - 39, 50, 22], voice: [74, h - 43, w - 194, 30],
        refresh: [w - 112, h - 44, 100, 32],
        rateLabel: [16, h - 78, 65, 22], rate: [80, h - 79, half - 174, 24],
        rateValue: [half - 87, h - 78, 83, 22],
        pitchLabel: [half + 10, h - 78, 60, 22], pitch: [half + 72, h - 79, half - 150, 24],
        pitchValue: [w - 69, h - 78, 55, 22],
        textLabel: [16, h - 117, 160, 22], open: [w - 144, h - 122, 132, 32],
        scroll: [16, 92, w - 32, h - 220],
        play: [12, 47, 100, 32], pause: [116, 47, 120, 32], stop: [240, 47, 88, 32],
        reset: [w - 170, 47, 158, 32], status: [16, 14, w - 32, 24]
    };
    Object.keys(frames).forEach(function (key) {
        frames[key] = frames[key].map(function (value) { return value * factor; });
    });
    return frames;
}

function layoutUI() {
    if (!ui.scroll) return;
    var size = ui.content.bounds.size;
    var frames = layoutFrames(Number(size.width), Number(size.height), scale);
    Object.keys(frames).forEach(function (key) {
        var frame = frames[key];
        ui[key].frame = $.NSMakeRect(frame[0], frame[1], frame[2], frame[3]);
        if (key !== 'scroll' && key !== 'rate' && key !== 'pitch') {
            ui[key].font = $.NSFont.systemFontOfSize(13 * scale);
        }
    });
    ui.editor.font = $.NSFont.systemFontOfSize(18 * scale);
    ui.editor.textContainerInset = $.NSMakeSize(12 * scale, 12 * scale);
    var width = Number(ui.scroll.contentSize.width);
    var editorFrame = ui.editor.frame;
    ui.editor.setFrameSize($.NSMakeSize(width, Math.max(Number(editorFrame.size.height), Number(ui.scroll.contentSize.height))));
    ui.editor.textContainer.containerSize = $.NSMakeSize(width, 1000000);
}

function setScale(requested) {
    if (!ui.window) return;
    var screen = ui.window.screen;
    if (!screen || screen.isNil()) screen = $.NSScreen.mainScreen;
    var available = screen.visibleFrame.size;
    var maxScale = Math.min(1.5, (Number(available.width) - 24) / 680, (Number(available.height) - 60) / 400);
    var next = clamp(Math.round(requested * 10) / 10, 0.8, maxScale, 1);
    var size = ui.content.bounds.size;
    var width = Math.max(680, Number(size.width) / scale);
    var height = Math.max(400, Number(size.height) / scale);
    scale = next;
    ui.window.contentMinSize = $.NSMakeSize(680 * scale, 400 * scale);
    ui.window.setContentSize($.NSMakeSize(Math.min(width * scale, Number(available.width) - 24),
        Math.min(height * scale, Number(available.height) - 60)));
    defaults.setDoubleForKey(scale, $('uiScale'));
    layoutUI();
}

function showAbout() {
    if (!about.window) {
        var path = $.NSBundle.mainBundle.pathForResourceOfType($('about'), $('mp4'));
        if (!path || path.isNil()) throw new Error('Не найдено видео About. Переустановите приложение из нового архива.');
        var window = $.NSWindow.alloc.initWithContentRectStyleMaskBackingDefer(
            $.NSMakeRect(0, 0, 440, 330), $.NSWindowStyleMaskTitled | $.NSWindowStyleMaskClosable,
            $.NSBackingStoreBuffered, false);
        window.title = $('О kasholkaTTS');
        window.releasedWhenClosed = false;
        window.delegate = controller;
        var player = $.AVQueuePlayer.alloc.init;
        player.muted = true;
        var item = $.AVPlayerItem.playerItemWithURL($.NSURL.fileURLWithPath(path));
        var looper = $.AVPlayerLooper.alloc.initWithPlayerTemplateItem(player, item);
        var background = $.NSView.alloc.initWithFrame($.NSMakeRect(0, 0, 440, 330));
        var videoLayer = $.AVPlayerLayer.playerLayerWithPlayer(player);
        videoLayer.videoGravity = $.AVLayerVideoGravityResizeAspectFill;
        background.layer = videoLayer;
        background.wantsLayer = true;
        window.contentView.addSubview(background);
        function overlay(text, y, height, size) {
            var label = $.NSTextField.labelWithString($(text));
            label.frame = $.NSMakeRect(16, y, 408, height);
            label.alignment = $.NSTextAlignmentCenter;
            label.font = $.NSFont.boldSystemFontOfSize(size);
            label.textColor = $.NSColor.whiteColor;
            label.drawsBackground = true;
            label.backgroundColor = $.NSColor.colorWithCalibratedWhiteAlpha(0, 0.65);
            window.contentView.addSubview(label);
        }
        overlay('kasholkaTTS', 146, 42, 30);
        overlay('vibecoded by strch', 46, 25, 15);
        overlay(VERSION, 22, 22, 12);
        about = { window: window, player: player, looper: looper, layer: videoLayer };
        window.center;
    }
    about.window.makeKeyAndOrderFront(null);
    about.player.play;
}

function installMenus() {
    var menu = $.NSMenu.alloc.init;
    var appItem = $.NSMenuItem.alloc.init;
    var appMenu = $.NSMenu.alloc.initWithTitle($('kasholkaTTS'));
    var aboutItem = appMenu.addItemWithTitleActionKeyEquivalent($('О kasholkaTTS'), 'about:', $(''));
    aboutItem.target = controller;
    appMenu.addItem($.NSMenuItem.separatorItem);
    appMenu.addItemWithTitleActionKeyEquivalent($('Скрыть kasholkaTTS'), 'hide:', $('h'));
    appMenu.addItemWithTitleActionKeyEquivalent($('Завершить kasholkaTTS'), 'terminate:', $('q'));
    appItem.submenu = appMenu;
    menu.addItem(appItem);
    var editItem = $.NSMenuItem.alloc.init;
    var editMenu = $.NSMenu.alloc.initWithTitle($('Правка'));
    [['Отменить', 'undo:', 'z'], ['Вырезать', 'cut:', 'x'], ['Копировать', 'copy:', 'c'],
        ['Вставить', 'paste:', 'v'], ['Выделить всё', 'selectAll:', 'a']].forEach(function (entry) {
        editMenu.addItemWithTitleActionKeyEquivalent($(entry[0]), entry[1], $(entry[2]));
    });
    editItem.submenu = editMenu;
    menu.addItem(editItem);
    var viewItem = $.NSMenuItem.alloc.init;
    var viewMenu = $.NSMenu.alloc.initWithTitle($('Вид'));
    [['Увеличить масштаб', 'zoomIn:', '='], ['Уменьшить масштаб', 'zoomOut:', '-'],
        ['Масштаб 100%', 'zoomReset:', '0']].forEach(function (entry) {
        var item = viewMenu.addItemWithTitleActionKeyEquivalent($(entry[0]), entry[1], $(entry[2]));
        item.target = controller;
    });
    viewItem.submenu = viewMenu;
    menu.addItem(viewItem);
    $.NSApplication.sharedApplication.mainMenu = menu;
}

function run() {
    if (ui.window) { ui.window.makeKeyAndOrderFront(null); return; }
    defaults = $.NSUserDefaults.standardUserDefaults;
    registerController();
    var app = $.NSApplication.sharedApplication;
    app.setActivationPolicy($.NSApplicationActivationPolicyRegular);
    var style = $.NSWindowStyleMaskTitled | $.NSWindowStyleMaskClosable |
        $.NSWindowStyleMaskMiniaturizable | $.NSWindowStyleMaskResizable;
    ui.window = $.NSWindow.alloc.initWithContentRectStyleMaskBackingDefer(
        $.NSMakeRect(0, 0, 760, 500), style, $.NSBackingStoreBuffered, false);
    ui.window.title = $('kasholkaTTS');
    ui.window.contentMinSize = $.NSMakeSize(680, 400);
    ui.window.releasedWhenClosed = false;
    ui.window.delegate = controller;
    ui.content = ui.window.contentView;

    ui.voiceLabel = addLabel('Голос', 13, false);
    ui.voice = $.NSPopUpButton.alloc.initWithFramePullsDown($.NSMakeRect(0, 0, 500, 32), false);
    ui.voice.target = controller;
    ui.voice.action = 'voice:';
    ui.content.addSubview(ui.voice);
    ui.refresh = addButton('Обновить', 'refresh:');
    ui.rateLabel = addLabel('Скорость', 13, false);
    ui.rate = addSlider(80, 400, clamp(unwrap(defaults.objectForKey($('rate')), 180), 80, 400, 180),
        'rate:');
    ui.rateValue = addLabel('', 13, true);
    ui.pitchLabel = addLabel('Высота', 13, false);
    ui.pitch = addSlider(36, 60, 48, 'pitch:');
    ui.pitchValue = addLabel('', 13, true);
    ui.textLabel = addLabel('ВАШ ТЕКСТ', 12, true);
    ui.open = addButton('Открыть .txt…', 'openText:');

    var scroll = $.NSScrollView.alloc.initWithFrame($.NSMakeRect(16, 92, 728, 280));
    ui.scroll = scroll;
    scroll.borderType = $.NSBezelBorder;
    scroll.hasVerticalScroller = true;
    ui.editor = $.NSTextView.alloc.initWithFrame($.NSMakeRect(0, 0, 820, 282));
    ui.editor.richText = false;
    ui.editor.allowsUndo = true;
    ui.editor.font = $.NSFont.systemFontOfSize(18);
    ui.editor.textColor = $.NSColor.textColor;
    ui.editor.backgroundColor = $.NSColor.textBackgroundColor;
    ui.editor.textContainerInset = $.NSMakeSize(16, 16);
    ui.editor.verticallyResizable = true;
    ui.editor.horizontallyResizable = false;
    ui.editor.minSize = $.NSMakeSize(0, 0);
    ui.editor.maxSize = $.NSMakeSize(1000000, 1000000);
    ui.editor.autoresizingMask = $.NSViewWidthSizable;
    ui.editor.textContainer.containerSize = $.NSMakeSize(820, 1000000);
    ui.editor.textContainer.widthTracksTextView = true;
    scroll.documentView = ui.editor;
    ui.content.addSubview(scroll);

    ui.play = addButton('Читать', 'play:');
    ui.pause = addButton('Пауза', 'pause:');
    ui.stop = addButton('Стоп', 'stop:');
    ui.reset = addButton('Сброс параметров', 'reset:');
    ui.status = addLabel('Загрузка голосов…', 13, false);
    installMenus();
    setScale(clamp(unwrap(defaults.objectForKey($('uiScale')), 1), 0.8, 1.5, 1));
    refreshVoices();
    ui.window.center;
    ui.window.makeKeyAndOrderFront(null);
    ui.window.makeFirstResponder(ui.editor);
    app.activateIgnoringOtherApps(true);
}

function reopen() {
    if (ui.window) ui.window.makeKeyAndOrderFront(null);
}

function idle() { return 30; }

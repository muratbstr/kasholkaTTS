// Run with the real macOS JXA bridge BEFORE building or replacing the app.
// Registers the controller and checks its selectors without opening a window
// or starting speech. This catches unavailable protocol metadata at install time.
ObjC.import('Foundation');

function run(argv) {
    if (argv.length !== 1) throw new Error('Expected the application source path');
    var error = Ref();
    var source = $.NSString.stringWithContentsOfFileEncodingError(
        $(argv[0]), $.NSUTF8StringEncoding, error);
    if (!source || source.isNil()) throw new Error('Cannot read application source');
    var check = new Function(ObjC.unwrap(source) + '\n' +
        'registerController();\n' +
        '["play:", "pause:", "stop:", "voice:", "refresh:", "rate:", "pitch:",\n' +
        ' "reset:", "openText:", "speechSynthesizer:didFinishSpeaking:", "windowWillClose:"]\n' +
        '.forEach(function (selector) {\n' +
        '    if (!controller.respondsToSelector(selector)) {\n' +
        '        throw new Error("Missing controller method: " + selector);\n' +
        '    }\n' +
        '});\n' +
        'return "JXA controller check passed";');
    return check();
}

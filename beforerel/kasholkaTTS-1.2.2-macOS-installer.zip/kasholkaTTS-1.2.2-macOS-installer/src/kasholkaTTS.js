/* kasholkaTTS 1.2.2 — macOS 12+, JavaScript for Automation / AppKit.
 * Compiled as a stay-open applet by the installer using macOS osacompile.
 * No browser, network, third-party runtime, or automation of other apps.
 */
ObjC.import('Cocoa');
ObjC.import('AVFoundation');

var VERSION = '1.2.2';
var ui = {};
var controller = null;
var synth = null;
var voices = [];
var active = false;
var paused = false;
var voiceBaseRate = 180;
var defaults = null;
var engine = 'ns';
var currentUtterance = null;
var scale = 1;
var about = {};
var avFoundationBundle = null;
var voiceProbe = null;
var hostSpeech = null;
var hostTimer = null;
var hostVoices = [];
var voiceDiagnostics = {};
var voiceInventories = {};

function readHostText(path) {
    return unwrap($.NSString.stringWithContentsOfFileEncodingError($(path), $.NSUTF8StringEncoding, Ref()), '');
}

function voiceDiagnosticText() {
    var os = unwrap($.NSProcessInfo.processInfo.operatingSystemVersionString, 'macOS');
    var lines = ['kasholkaTTS ' + VERSION, os];
    ['app', 'osascript', 'swift'].forEach(function (name) {
        lines.push('\n' + name + ': ' + (voiceDiagnostics[name] || 'Пока не проверено'));
        (voiceInventories[name] || []).forEach(function (voice) {
            lines.push(voice.id + ' | ' + voice.name + ' | ' + voice.locale);
        });
    });
    return lines.join('\n');
}

function showVoiceDiagnostics() {
    var dialog = $.NSAlert.alloc.init;
    dialog.messageText = $('Диагностика голосов');
    dialog.informativeText = $(['app', 'osascript', 'swift'].map(function (name) {
        return name + ': ' + (voiceDiagnostics[name] || 'Пока не проверено');
    }).join('\n\n').slice(0, 2000) + '\n\nВ отчёте — версия macOS, ошибки и идентификаторы голосов. Вашего текста там нет.');
    dialog.addButtonWithTitle($('Скопировать отчёт'));
    dialog.addButtonWithTitle($('Закрыть'));
    if (Number(dialog.runModal) === 1000) {
        var pasteboard = $.NSPasteboard.generalPasteboard;
        pasteboard.clearContents;
        pasteboard.setStringForType($(voiceDiagnosticText()), $.NSPasteboardTypeString);
        status('Отчёт о голосах скопирован.');
    }
}

function recordVoiceInventory(backend, list) {
    voiceInventories[backend] = list;
    var siri = list.filter(isSiriVoice);
    voiceDiagnostics[backend] = 'Всего: ' + list.length + ', Siri: ' + siri.length +
        '\nSiri по языкам: ' + ['en-GB', 'en-US', 'ru-RU'].map(function (locale) {
            return locale + ': ' + siri.filter(function (voice) {
                return String(voice.locale || '').replace(/_/g, '-').toLowerCase() === locale.toLowerCase();
            }).length;
        }).join(', ');
}

function writeHostJSON(path, value) {
    if (!$(JSON.stringify(value)).writeToFileAtomicallyEncodingError($(path), true, $.NSUTF8StringEncoding, Ref())) {
        throw new Error('Не удалось записать данные речевого помощника.');
    }
}

function readHostJSON(path) {
    var data = $.NSString.stringWithContentsOfFileEncodingError($(path), $.NSUTF8StringEncoding, Ref());
    return !data || data.isNil() ? null : JSON.parse(ObjC.unwrap(data));
}

function sendHostCommand(job, command) {
    if (command) job.command = command;
    job.heartbeat = Date.now();
    writeHostJSON(job.directory + '/control.json', { command: job.command, time: job.heartbeat });
}

function disposeHostJob(job) {
    if (!job) return;
    // Kill only our own NSTask, never another osascript or a system service.
    try { if (job.task && job.task.running) job.task.terminate; } catch (exited) {}
    // Individual known files only. The child never recreates its directory.
    if (job.errorHandle) { try { job.errorHandle.closeFile; } catch (closed) {} }
    ['request.json', 'control.json', 'result.json', 'stderr.txt'].forEach(function (name) {
        try { $.NSFileManager.defaultManager.removeItemAtPathError($(job.directory + '/' + name), Ref()); } catch (missing) {}
    });
    // rmdir is nonrecursive and refuses an unexpectedly nonempty directory.
    try { $.rmdir(job.directory); } catch (missing) {}
}

function createHostLog(path) {
    // JS null can bridge to NSNull, which is neither NSData nor NSDictionary.
    // Pass concrete Foundation objects even for an empty file/default attrs.
    if (!$.NSFileManager.defaultManager.createFileAtPathContentsAttributes(
        $(path), $.NSData.data, $.NSDictionary.dictionary)) {
        throw new Error('Не удалось создать журнал речевого помощника.');
    }
    var handle = $.NSFileHandle.fileHandleForWritingAtPath($(path));
    if (!handle || handle.isNil()) throw new Error('Не удалось открыть журнал речевого помощника.');
    return handle;
}

function startHostJob(mode, request, backend) {
    backend = backend || 'osascript';
    var path = $.NSBundle.mainBundle.pathForResourceOfType($('voice-host'), $(backend === 'swift' ? 'swift' : 'js'));
    if (!path || path.isNil()) throw new Error('Не найден речевой помощник. Переустановите приложение.');
    var launcher = null;
    if (backend === 'swift') {
        launcher = $.NSBundle.mainBundle.pathForResourceOfType($('voice-host-swift'), $('sh'));
        if (!launcher || launcher.isNil()) throw new Error('Не найден запускатель Swift. Переустановите приложение.');
    }
    var directory = unwrap($.NSTemporaryDirectory(), '') + 'kasholkaTTS-' + unwrap($.NSUUID.UUID.UUIDString, '');
    var permissions = $.NSMutableDictionary.alloc.init;
    permissions.setObjectForKey($(448), $.NSFilePosixPermissions); // 0700
    if (!$.NSFileManager.defaultManager.createDirectoryAtPathWithIntermediateDirectoriesAttributesError(
        $(directory), false, permissions, Ref())) throw new Error('Не удалось создать папку речевого помощника.');
    var timeout = backend === 'swift' ? 60 : 15;
    var job = { directory: directory, mode: mode, backend: backend, timeout: timeout,
        command: 'play', deadline: Date.now() + timeout * 1000, ready: false };
    try {
        writeHostJSON(directory + '/request.json', request || {});
        sendHostCommand(job);
        job.task = $.NSTask.alloc.init;
        job.task.launchPath = $(backend === 'swift' ? '/bin/bash' : '/usr/bin/osascript');
        job.task.arguments = $(backend === 'swift' ?
            [unwrap(launcher, ''), unwrap(path, ''), mode, directory] :
            ['-l', 'JavaScript', unwrap(path, ''), mode, directory]);
        job.task.standardInput = $.NSFileHandle.fileHandleWithNullDevice;
        job.task.standardOutput = $.NSFileHandle.fileHandleWithNullDevice;
        job.errorHandle = createHostLog(directory + '/stderr.txt');
        job.task.standardError = job.errorHandle;
        job.task.launch;
        if (!hostTimer) {
            hostTimer = $.NSTimer.scheduledTimerWithTimeIntervalTargetSelectorUserInfoRepeats(
                0.2, controller, 'hostTick:', null, true);
            $.NSRunLoop.mainRunLoop.addTimerForMode(hostTimer, $.NSRunLoopCommonModes);
        }
        return job;
    } catch (error) { disposeHostJob(job); throw error; }
}

function voiceKey(voice) {
    return (voice.engine === 'host' ? (voice.backend === 'swift' ? 'swift:' : 'host:') : voice.engine === 'av' ? 'av:' : '') + voice.id;
}

function addHostVoices(list) {
    var seen = {};
    voices.forEach(function (voice) { seen[voice.id] = true; });
    list.forEach(function (voice) {
        if (!voice || typeof voice.id !== 'string' || !voice.id || seen[voice.id]) return;
        seen[voice.id] = true;
        voices.push({ id: voice.id, name: String(voice.name || voice.id),
            locale: String(voice.locale || ''), engine: 'host', backend: voice.backend || 'osascript' });
    });
}

function beginVoiceProbe(backend) {
    backend = backend || 'osascript';
    disposeHostJob(voiceProbe);
    voiceProbe = null;
    try {
        voiceDiagnostics[backend] = 'Проверяется…';
        voiceProbe = startHostJob('list', null, backend);
        if (!active) status(backend === 'swift' ? 'Проверяю Siri через Swift (до 60 с)…' : 'Проверяю Siri через osascript…');
    } catch (error) {
        voiceDiagnostics[backend] = String(error);
        finishVoiceProbe(backend, false);
    }
}

function finishVoiceProbe(backend, succeeded) {
    var preferred = unwrap(defaults.stringForKey($('voice')), '');
    if (backend === 'osascript' && (!voices.some(isSiriVoice) || preferred.indexOf('swift:') === 0)) {
        beginVoiceProbe('swift');
        return;
    }
    if (backend === 'osascript') voiceDiagnostics.swift = 'Не запускался: Siri уже найдены.';
    if (active) return;
    var count = voices.filter(isSiriVoice).length;
    if (count) status('Найдено голосов Siri: ' + count + '. Выберите [Siri] в списке.');
    else status(succeeded ? 'Siri не найдены. Подробности: меню → Диагностика голосов.' :
        'Проверка Siri не завершена. Меню → Диагностика голосов.');
}

function pollHostJob(job) {
    var result = readHostJSON(job.directory + '/result.json');
    if (result && result.state === 'error') throw new Error(result.message);
    if (result && (result.state === 'voices' || result.state === 'finished')) return result;
    if (!job.task.running) {
        var detail = readHostText(job.directory + '/stderr.txt').trim().slice(0, 4000);
        throw new Error('Помощник ' + job.backend + ' завершился (код ' + job.task.terminationStatus + '). ' + detail);
    }
    if (result && (result.state === 'speaking' || result.state === 'paused')) job.ready = true;
    if (!job.ready && Date.now() > job.deadline) throw new Error('Речевой помощник не ответил за ' + job.timeout + ' секунд.');
    if (Date.now() - job.heartbeat > 2000) sendHostCommand(job);
    return result;
}

function hostTick() {
    if (voiceProbe) {
        var probeBackend = voiceProbe.backend;
        try {
            var inventory = pollHostJob(voiceProbe);
            // Keep the current voice menu stable until a reading finishes.
            if (inventory && inventory.state === 'voices' && !active) {
                if (!Array.isArray(inventory.voices)) throw new Error('Некорректный список голосов.');
                recordVoiceInventory(probeBackend, inventory.voices);
                hostVoices = hostVoices.filter(function (voice) { return (voice.backend || 'osascript') !== probeBackend; });
                hostVoices = hostVoices.concat(inventory.voices.map(function (voice) {
                    return { id: voice.id, name: voice.name, locale: voice.locale, backend: probeBackend };
                }));
                disposeHostJob(voiceProbe);
                voiceProbe = null;
                var preferred = unwrap(defaults.stringForKey($('voice')), '');
                voices = voices.filter(function (voice) { return voice.engine !== 'host'; });
                addHostVoices(hostVoices);
                populateVoices(preferred, false);
                finishVoiceProbe(probeBackend, true);
            }
        } catch (error) {
            disposeHostJob(voiceProbe);
            voiceProbe = null;
            voiceDiagnostics[probeBackend] = String(error);
            finishVoiceProbe(probeBackend, false);
        }
    }
    if (hostSpeech) {
        try {
            var result = pollHostJob(hostSpeech);
            if (result && result.state === 'finished') {
                disposeHostJob(hostSpeech);
                hostSpeech = null;
                active = false;
                paused = false;
                status('Прочитано');
                updateControls();
            } else if (result && (result.state === 'speaking' || result.state === 'paused')) {
                paused = result.state === 'paused';
                status(paused ? 'Пауза' : 'Читаю текст…');
                updateControls();
            }
        } catch (error) {
            disposeHostJob(hostSpeech);
            hostSpeech = null;
            active = false;
            paused = false;
            status('Чтение: ' + String(error));
            updateControls();
        }
    }
    if (!voiceProbe && !hostSpeech && hostTimer) {
        hostTimer.invalidate;
        hostTimer = null;
    }
}

function closeHosts() {
    disposeHostJob(voiceProbe);
    disposeHostJob(hostSpeech);
    voiceProbe = hostSpeech = null;
    if (hostTimer) hostTimer.invalidate;
    hostTimer = null;
}

function avFoundationClass(name) {
    var klass = $[name];
    if (klass && !(klass.isNil && klass.isNil())) return klass;
    var bundle = $.NSBundle.bundleWithPath($('/System/Library/Frameworks/AVFoundation.framework'));
    if (!bundle || bundle.isNil() || !bundle.load) {
        throw new Error('Не удалось загрузить системный мультимедийный движок.');
    }
    // Keep the loaded bundle alive for as long as its classes are in use.
    avFoundationBundle = bundle;
    klass = $.NSClassFromString($(name));
    if (!klass || klass.isNil && klass.isNil()) {
        throw new Error('Системный класс недоступен: ' + name);
    }
    return klass;
}

function stopSynth() {
    currentUtterance = null;
    if (engine === 'host') {
        disposeHostJob(hostSpeech);
        hostSpeech = null;
        return;
    }
    if (!synth) return;
    synth.delegate = null;
    if (engine === 'av') synth.stopSpeakingAtBoundary(0);
    else synth.stopSpeaking;
}

function finishAV(sender, utterance, finished) {
    if (!synth || !sender.isEqual(synth) || !active || !currentUtterance ||
        !utterance.isEqual(currentUtterance)) return;
    active = false;
    paused = false;
    currentUtterance = null;
    status(finished ? 'Прочитано' : 'Чтение прервано');
    updateControls();
}

function unwrap(value, fallback) {
    if (value === undefined || value === null || value.isNil && value.isNil()) return fallback;
    var result = ObjC.unwrap(value);
    return result === undefined || result === null ? fallback : result;
}

function clamp(value, low, high, fallback) {
    value = Number(value);
    return isFinite(value) ? Math.max(low, Math.min(high, value)) : fallback;
}

function textToRead(text, location, length) {
    // NSString/NSTextView ranges and JS strings both count UTF-16 code units.
    return length > 0 ? text.substr(location, length) : text;
}

function status(message) {
    if (ui.status) {
        ui.status.stringValue = $(message);
        ui.status.toolTip = $(message);
    }
}

function alertUser(title, message) {
    var alert = $.NSAlert.alloc.init;
    alert.messageText = $(title);
    alert.informativeText = $(message);
    alert.addButtonWithTitle($('OK'));
    alert.runModal;
}

function guarded(action) {
    return function () {
        try { action(); }
        catch (error) {
            status('Ошибка. Попробуйте другой голос или перезапустите приложение.');
            alertUser('kasholkaTTS', String(error));
        }
    };
}

function updateControls() {
    var ready = !!synth && voices.length > 0;
    ui.play.enabled = ready && !active;
    ui.pause.enabled = active;
    ui.pause.title = $(paused ? 'Продолжить' : 'Пауза');
    ui.stop.enabled = active;
    ui.voice.enabled = !active && voices.length > 0;
    ui.refresh.enabled = !active;
    ui.rate.enabled = ready && !active;
    ui.reset.enabled = ready && !active;
    ui.open.enabled = !active;
    ui.editor.editable = !active;
}

function speedFactor(position) {
    // Smooth, monotonic setting: slow / natural / fast, with natural at center.
    return Math.pow(2, 2 * clamp(position, 0, 1, 0.5) - 1);
}

function applyRate() {
    var position = clamp(ui.rate.doubleValue, 0, 1, 0.5);
    var factor = speedFactor(position);
    // Never write back to the knob from its action while the user is dragging.
    ui.rateValue.stringValue = $(engine !== 'ns' ? factor.toFixed(2) + '×' :
        Math.round(voiceBaseRate * factor) + ' сл/мин');
    defaults.setDoubleForKey(position, $('speedPosition'));
}

function selectVoice(savePreference) {
    if (active || !voices.length) return;
    var item = voices[Number(ui.voice.indexOfSelectedItem)];
    if (!item) return;
    // Each new synthesizer starts with the voice's natural pitch and rate.
    stopSynth();
    engine = item.engine || 'ns';
    synth = engine === 'host' ? { isNil: function () { return false; } } :
        engine === 'av' ? avFoundationClass('AVSpeechSynthesizer').alloc.init :
        $.NSSpeechSynthesizer.alloc.initWithVoice($(item.id));
    if (!synth || synth.isNil()) {
        synth = null;
        status('Голос недоступен. Выберите другой или обновите список.');
        updateControls();
        return;
    }
    synth.delegate = controller;
    voiceBaseRate = engine === 'ns' ? clamp(synth.rate, 80, 400, 180) : 180;
    if (savePreference !== false) defaults.setObjectForKey($(voiceKey(item)), $('voice'));
    applyRate();
    status('Готово • ' + item.name);
    updateControls();
}

function isSiriVoice(voice) {
    // Both com.apple.siri.* and older com.apple.ttsbundle.siri_* identifiers
    // occur in system voice inventories. A display name explicitly saying Siri
    // is also valid; ordinary human names alone are not evidence of Siri.
    return /(^|[._-])siri([._-]|$)/i.test(voice.id || '') || /\bsiri\b/i.test(voice.name || '');
}

function refreshVoices() {
    if (active) return;
    voiceDiagnostics = {};
    voiceInventories = {};
    var preferred = unwrap(defaults.stringForKey($('voice')), '');
    if (!preferred) preferred = unwrap($.NSSpeechSynthesizer.defaultVoice, '');
    var available = $.NSSpeechSynthesizer.availableVoices;
    voices = [];
    for (var i = 0; i < Number(available.count); i++) {
        var id = available.objectAtIndex(i);
        var attrs = $.NSSpeechSynthesizer.attributesForVoice(id);
        voices.push({
            engine: 'ns',
            id: unwrap(id, ''),
            name: unwrap(attrs.objectForKey($.NSVoiceName), unwrap(id, 'Голос')),
            locale: unwrap(attrs.objectForKey($.NSVoiceLocaleIdentifier), '')
        });
    }
    // Public AVFoundation API exposes additional voices on some Macs, including
    // Siri when the OS makes them available. Never fabricate hidden identifiers.
    var avFailed = false;
    try {
        var modern = avFoundationClass('AVSpeechSynthesisVoice').speechVoices;
        var seen = {};
        voices.forEach(function (voice) { seen[voice.id] = true; });
        for (var j = 0; j < Number(modern.count); j++) {
            var nativeVoice = modern.objectAtIndex(j);
            var identifier = unwrap(nativeVoice.identifier, '');
            if (!identifier || seen[identifier]) continue;
            seen[identifier] = true;
            voices.push({ id: identifier, engine: 'av',
                name: unwrap(nativeVoice.name, identifier),
                locale: unwrap(nativeVoice.language, '') });
        }
    } catch (error) { avFailed = true; }
    recordVoiceInventory('app', voices.slice());
    // Recheck cached helper voices before offering them in a new inventory.
    hostVoices = [];
    addHostVoices(hostVoices);
    populateVoices(preferred, avFailed);
    beginVoiceProbe();
}

function populateVoices(preferred, avFailed) {
    voices.sort(function (a, b) {
        return (a.locale + a.name + a.id).localeCompare(b.locale + b.name + b.id);
    });
    ui.voice.removeAllItems;
    var selected = 0, siriCount = 0;
    voices.forEach(function (voice, index) {
        // NSPopUpButton coalesces duplicate titles; keep every voice selectable.
        var siri = isSiriVoice(voice);
        if (siri) siriCount++;
        ui.voice.addItemWithTitle($((index + 1) + '. ' + (siri ? '[Siri] ' : '') + voice.name + ' · ' + voice.locale));
        if (voiceKey(voice) === preferred) selected = index;
    });
    if (voices.length) {
        ui.voice.selectItemAtIndex(selected);
        selectVoice(false);
    } else {
        stopSynth();
        synth = null;
        status('Нет доступных голосов. Добавьте голос в настройках macOS и нажмите «Обновить».');
        updateControls();
    }
    if (!active && avFailed) status('Дополнительные голоса недоступны. Обычные голоса можно использовать.');
    else if (!active && voices.length && !siriCount) status('Голоса загружены. Siri не предоставлены приложению на этом Mac.');
    ui.voice.toolTip = $('Голосов Siri в списке: ' + siriCount);
}

function play() {
    if (active || !synth) return;
    var range = ui.editor.selectedRange;
    var text = textToRead(unwrap(ui.editor.string, ''), Number(range.location), Number(range.length));
    if (!text.trim()) { status('Введите текст или выделите фрагмент для чтения.'); return; }
    // Recreate the synthesizer for EVERY reading, including after a natural
    // finish. Apply the final slider position explicitly to this new instance.
    selectVoice();
    if (!synth) return;
    active = true;
    paused = false;
    status(range.length > 0 ? 'Читаю выделенный фрагмент…' : 'Читаю текст…');
    updateControls();
    var started;
    try {
        if (engine === 'host') {
            var hostVoice = voices[Number(ui.voice.indexOfSelectedItem)];
            hostSpeech = startHostJob('speak', { id: hostVoice.id, text: text,
                factor: speedFactor(ui.rate.doubleValue) }, hostVoice.backend);
            status('Запускаю выбранный голос…');
            started = true;
        } else if (engine === 'av') {
            var item = voices[Number(ui.voice.indexOfSelectedItem)];
            var avVoice = avFoundationClass('AVSpeechSynthesisVoice').voiceWithIdentifier($(item.id));
            if (!avVoice || avVoice.isNil()) throw new Error('Выбранный голос больше недоступен. Обновите список.');
            currentUtterance = avFoundationClass('AVSpeechUtterance').speechUtteranceWithString($(text));
            currentUtterance.voice = avVoice;
            var naturalRate = clamp(currentUtterance.rate, 0.1, 1, 0.5);
            currentUtterance.rate = clamp(naturalRate * speedFactor(ui.rate.doubleValue), 0.1, 1, 0.5);
            synth.speakUtterance(currentUtterance);
            started = true;
        } else {
            synth.setRate(voiceBaseRate * speedFactor(ui.rate.doubleValue));
            started = synth.startSpeakingString($(text));
        }
    }
    catch (error) {
        active = false;
        currentUtterance = null;
        updateControls();
        throw error;
    }
    if (!started) {
        active = false;
        status('Не удалось начать чтение. Попробуйте другой голос.');
        updateControls();
    }
}

function pauseOrResume() {
    if (!active || !synth) return;
    if (engine === 'host') {
        if (hostSpeech) sendHostCommand(hostSpeech, hostSpeech.command === 'pause' ? 'play' : 'pause');
        return; // UI follows the helper's acknowledgement, including refusal.
    }
    if (paused) {
        var resumed = synth.continueSpeaking;
        if (engine === 'av' && !resumed) return;
        paused = false;
        status('Читаю текст…');
    } else {
        var didPause = synth.pauseSpeakingAtBoundary(engine === 'av' ? 0 : $.NSSpeechImmediateBoundary);
        if (engine === 'av' && !didPause) return;
        paused = true;
        status('Пауза');
    }
    updateControls();
}

function stop() {
    // Detach before stopping: late completion callbacks must not finish a new run.
    active = false;
    paused = false;
    stopSynth();
    selectVoice();
    status('Остановлено');
    updateControls();
}

function reset() {
    if (active) return;
    ui.rate.doubleValue = 0.5;
    applyRate();
    status('Параметры голоса сброшены');
}

function openText() {
    var panel = $.NSOpenPanel.openPanel;
    panel.title = $('Открыть текст');
    panel.allowedFileTypes = $(['txt', 'text', 'md']);
    panel.allowsMultipleSelection = false;
    panel.canChooseDirectories = false;
    if (panel.runModal !== $.NSModalResponseOK) return;
    var error = Ref();
    var text = $.NSString.stringWithContentsOfURLUsedEncodingError(panel.URL, Ref(), error);
    if (!text || text.isNil()) {
        alertUser('Не удалось открыть файл', 'Сохраните его как обычный текст UTF-8 или UTF-16 и попробуйте снова.');
        return;
    }
    ui.editor.string = text;
    status('Файл открыт. Нажмите «Читать».');
}

function registerController() {
    ObjC.registerSubclass({
        name: 'KasholkaController',
        superclass: 'NSObject',
        // Do not resolve delegate protocols through JXA: their metadata may be
        // unavailable on Monterey ("protocol does not exist"). Cocoa dispatches
        // these optional callbacks by selector. Explicit types below provide
        // the signatures without requiring protocol lookup by the bridge.
        methods: {
            'play:': { types: ['void', ['id']], implementation: guarded(play) },
            'pause:': { types: ['void', ['id']], implementation: guarded(pauseOrResume) },
            'stop:': { types: ['void', ['id']], implementation: guarded(stop) },
            'voice:': { types: ['void', ['id']], implementation: guarded(selectVoice) },
            'refresh:': { types: ['void', ['id']], implementation: guarded(refreshVoices) },
            'rate:': { types: ['void', ['id']], implementation: guarded(applyRate) },
            'reset:': { types: ['void', ['id']], implementation: guarded(reset) },
            'openText:': { types: ['void', ['id']], implementation: guarded(openText) },
            'about:': { types: ['void', ['id']], implementation: guarded(showAbout) },
            'hostTick:': { types: ['void', ['id']], implementation: hostTick },
            'voiceDiagnostics:': { types: ['void', ['id']], implementation: guarded(showVoiceDiagnostics) },
            'quitApp:': { types: ['void', ['id']], implementation: guarded(terminateApp) },
            'zoomIn:': { types: ['void', ['id']], implementation: guarded(function () { setScale(scale + 0.1); }) },
            'zoomOut:': { types: ['void', ['id']], implementation: guarded(function () { setScale(scale - 0.1); }) },
            'zoomReset:': { types: ['void', ['id']], implementation: guarded(function () { setScale(1); }) },
            'speechSynthesizer:didFinishSpeechUtterance:': {
                types: ['void', ['id', 'id']], implementation: function (sender, utterance) { finishAV(sender, utterance, true); }
            },
            'speechSynthesizer:didCancelSpeechUtterance:': {
                types: ['void', ['id', 'id']], implementation: function (sender, utterance) { finishAV(sender, utterance, false); }
            },
            'speechSynthesizer:didFinishSpeaking:': {
                types: ['void', ['id', 'bool']],
                implementation: function (sender, finished) {
                    if (!synth || !sender.isEqual(synth) || !active) return;
                    active = false;
                    paused = false;
                    status(finished ? 'Прочитано' : 'Чтение прервано');
                    updateControls();
                }
            },
            'windowWillClose:': {
                types: ['void', ['id']],
                implementation: function (notification) {
                    if (notification && about.window && notification.object.isEqual(about.window)) {
                        if (about.player) about.player.pause;
                        return;
                    }
                    terminateApp();
                }
            },
            'windowDidResize:': {
                types: ['void', ['id']], implementation: function (notification) {
                    if (ui.window && notification.object.isEqual(ui.window)) layoutUI();
                }
            }
        }
    });
    controller = $.KasholkaController.alloc.init;
}

function addLabel(text, size, secondary) {
    var label = $.NSTextField.labelWithString($(text));
    label.font = $.NSFont.systemFontOfSize(size || 13);
    label.textColor = secondary ? $.NSColor.secondaryLabelColor : $.NSColor.labelColor;
    ui.content.addSubview(label);
    return label;
}

function addButton(title, selector) {
    var button = $.NSButton.alloc.initWithFrame($.NSMakeRect(0, 0, 100, 32));
    button.title = $(title);
    button.bezelStyle = $.NSBezelStyleRounded;
    button.target = controller;
    button.action = selector;
    ui.content.addSubview(button);
    return button;
}

function addSlider(min, max, value, selector) {
    var slider = $.NSSlider.alloc.initWithFrame($.NSMakeRect(0, 0, 100, 24));
    slider.minValue = min;
    slider.maxValue = max;
    slider.doubleValue = value;
    slider.continuous = false;
    slider.target = controller;
    slider.action = selector;
    ui.content.addSubview(slider);
    return slider;
}

function layoutFrames(width, height, factor) {
    var w = width / factor, h = height / factor;
    var frames = {
        voiceLabel: [16, h - 39, 50, 22], voice: [74, h - 43, w - 194, 30],
        refresh: [w - 112, h - 44, 100, 32],
        rateLabel: [16, h - 78, 65, 22], rate: [80, h - 79, w - 200, 24],
        rateValue: [w - 106, h - 78, 90, 22],
        textLabel: [16, h - 117, 160, 22], open: [w - 144, h - 122, 132, 32],
        scroll: [16, 92, w - 32, h - 220],
        play: [12, 47, 100, 32], pause: [116, 47, 120, 32], stop: [240, 47, 88, 32],
        reset: [w - 170, 47, 158, 32], status: [16, 14, w - 32, 24]
    };
    Object.keys(frames).forEach(function (key) {
        frames[key] = frames[key].map(function (value) { return value * factor; });
    });
    return frames;
}

function layoutUI() {
    if (!ui.scroll) return;
    var size = ui.content.bounds.size;
    var frames = layoutFrames(Number(size.width), Number(size.height), scale);
    Object.keys(frames).forEach(function (key) {
        var frame = frames[key];
        ui[key].frame = $.NSMakeRect(frame[0], frame[1], frame[2], frame[3]);
        if (key !== 'scroll' && key !== 'rate') {
            ui[key].font = $.NSFont.systemFontOfSize(13 * scale);
        }
    });
    ui.editor.font = $.NSFont.systemFontOfSize(18 * scale);
    ui.editor.textContainerInset = $.NSMakeSize(12 * scale, 12 * scale);
    var width = Number(ui.scroll.contentSize.width);
    var editorFrame = ui.editor.frame;
    ui.editor.setFrameSize($.NSMakeSize(width, Math.max(Number(editorFrame.size.height), Number(ui.scroll.contentSize.height))));
    ui.editor.textContainer.containerSize = $.NSMakeSize(width, 1000000);
}

function setScale(requested) {
    if (!ui.window) return;
    var screen = ui.window.screen;
    if (!screen || screen.isNil()) screen = $.NSScreen.mainScreen;
    var available = screen.visibleFrame.size;
    var maxScale = Math.min(1.5, (Number(available.width) - 24) / 680, (Number(available.height) - 60) / 400);
    var next = clamp(Math.round(requested * 10) / 10, 0.8, maxScale, 1);
    var size = ui.content.bounds.size;
    var width = Math.max(680, Number(size.width) / scale);
    var height = Math.max(400, Number(size.height) / scale);
    scale = next;
    ui.window.contentMinSize = $.NSMakeSize(680 * scale, 400 * scale);
    ui.window.setContentSize($.NSMakeSize(Math.min(width * scale, Number(available.width) - 24),
        Math.min(height * scale, Number(available.height) - 60)));
    defaults.setDoubleForKey(scale, $('uiScale'));
    layoutUI();
}

function videoClasses() {
    // ObjC.import loads bridge metadata, but $.AVQueuePlayer can still be
    // undefined in an applet. Load the framework binary and resolve its
    // Objective-C classes directly instead of relying on those JS bindings.
    var result = {};
    ['AVQueuePlayer', 'AVPlayerItem', 'AVPlayerLooper', 'AVPlayerLayer'].forEach(function (name) {
        result[name] = avFoundationClass(name);
    });
    result.bundle = avFoundationBundle;
    return result;
}

function aboutVideoLayout(width, height) {
    // The bundled about.mp4 has a 854 x 480 video track. Give the player a
    // matching rectangle that COVERS the window, then clip the excess. This
    // also works when JXA doesn't expose AVFoundation's gravity constants.
    var factor = Math.max(width / 854, height / 480);
    var videoWidth = 854 * factor, videoHeight = 480 * factor;
    return [(width - videoWidth) / 2, (height - videoHeight) / 2, videoWidth, videoHeight];
}

function startAboutVideo() {
    if (about.player) { about.player.play; return; }
    var player = null, looper = null, background = null;
    try {
        var path = $.NSBundle.mainBundle.pathForResourceOfType($('about'), $('mp4'));
        if (!path || path.isNil()) throw new Error('Не найдено видео About. Переустановите приложение из нового архива.');
        var classes = videoClasses();
        player = classes.AVQueuePlayer.alloc.initWithItems($([]));
        player.muted = true;
        var item = classes.AVPlayerItem.playerItemWithURL($.NSURL.fileURLWithPath(path));
        // Objective-C exposes this two-argument API as a CLASS factory.
        // The Swift convenience initializer is not an Objective-C selector.
        looper = classes.AVPlayerLooper.playerLooperWithPlayerTemplateItem(player, item);
        var videoLayer = classes.AVPlayerLayer.playerLayerWithPlayer(player);
        var content = about.window.contentView;
        var size = content.bounds.size;
        var frame = aboutVideoLayout(Number(size.width), Number(size.height));
        content.wantsLayer = true;
        content.layer.masksToBounds = true;
        background = $.NSView.alloc.initWithFrame($.NSMakeRect(frame[0], frame[1], frame[2], frame[3]));
        background.layer = videoLayer;
        background.wantsLayer = true;
        videoLayer.frame = $.NSMakeRect(0, 0, frame[2], frame[3]);
        // The text is already present; always insert video UNDER the labels.
        about.window.contentView.addSubviewPositionedRelativeTo(background, $.NSWindowBelow, null);
        player.play;
        about.player = player;
        about.looper = looper;
        about.layer = videoLayer;
        about.background = background;
        about.framework = classes.bundle;
    } catch (error) {
        // Do not leave a half-created player/window behind or stop TTS.
        if (player) { try { player.pause; } catch (ignored) {} }
        if (looper) { try { looper.disableLooping; } catch (ignored) {} }
        if (background) { try { background.removeFromSuperview; } catch (ignored) {} }
        status('About открыто без видео: ' + String(error));
    }
}

function showAbout() {
    if (!about.window) {
        var window = $.NSWindow.alloc.initWithContentRectStyleMaskBackingDefer(
            $.NSMakeRect(0, 0, 440, 330), $.NSWindowStyleMaskTitled | $.NSWindowStyleMaskClosable,
            $.NSBackingStoreBuffered, false);
        window.title = $('О kasholkaTTS');
        window.releasedWhenClosed = false;
        window.delegate = controller;
        function overlay(text, y, height, size) {
            var label = $.NSTextField.labelWithString($(text));
            label.frame = $.NSMakeRect(16, y, 408, height);
            label.alignment = $.NSTextAlignmentCenter;
            label.font = $.NSFont.boldSystemFontOfSize(size);
            label.textColor = $.NSColor.whiteColor;
            label.drawsBackground = true;
            label.backgroundColor = $.NSColor.colorWithCalibratedWhiteAlpha(0, 0.65);
            window.contentView.addSubview(label);
        }
        overlay('kasholkaTTS', 146, 42, 30);
        overlay('vibecoded by strch', 46, 25, 15);
        overlay(VERSION, 22, 22, 12);
        about = { window: window };
        window.center;
    }
    about.window.makeKeyAndOrderFront(null);
    startAboutVideo();
}

function installMenus() {
    var menu = $.NSMenu.alloc.init;
    var appItem = $.NSMenuItem.alloc.init;
    var appMenu = $.NSMenu.alloc.initWithTitle($('kasholkaTTS'));
    var aboutItem = appMenu.addItemWithTitleActionKeyEquivalent($('О kasholkaTTS'), 'about:', $(''));
    aboutItem.target = controller;
    var diagnosticItem = appMenu.addItemWithTitleActionKeyEquivalent($('Диагностика голосов…'), 'voiceDiagnostics:', $(''));
    diagnosticItem.target = controller;
    appMenu.addItem($.NSMenuItem.separatorItem);
    appMenu.addItemWithTitleActionKeyEquivalent($('Скрыть kasholkaTTS'), 'hide:', $('h'));
    var quitItem = appMenu.addItemWithTitleActionKeyEquivalent($('Завершить kasholkaTTS'), 'quitApp:', $('q'));
    quitItem.target = controller;
    appItem.submenu = appMenu;
    menu.addItem(appItem);
    var editItem = $.NSMenuItem.alloc.init;
    var editMenu = $.NSMenu.alloc.initWithTitle($('Правка'));
    [['Отменить', 'undo:', 'z'], ['Вырезать', 'cut:', 'x'], ['Копировать', 'copy:', 'c'],
        ['Вставить', 'paste:', 'v'], ['Выделить всё', 'selectAll:', 'a']].forEach(function (entry) {
        editMenu.addItemWithTitleActionKeyEquivalent($(entry[0]), entry[1], $(entry[2]));
    });
    editItem.submenu = editMenu;
    menu.addItem(editItem);
    var viewItem = $.NSMenuItem.alloc.init;
    var viewMenu = $.NSMenu.alloc.initWithTitle($('Вид'));
    [['Увеличить масштаб', 'zoomIn:', '='], ['Уменьшить масштаб', 'zoomOut:', '-'],
        ['Масштаб 100%', 'zoomReset:', '0']].forEach(function (entry) {
        var item = viewMenu.addItemWithTitleActionKeyEquivalent($(entry[0]), entry[1], $(entry[2]));
        item.target = controller;
    });
    viewItem.submenu = viewMenu;
    menu.addItem(viewItem);
    $.NSApplication.sharedApplication.mainMenu = menu;
}

function run() {
    if (ui.window) { ui.window.makeKeyAndOrderFront(null); return; }
    defaults = $.NSUserDefaults.standardUserDefaults;
    ObjC.bindFunction('rmdir', ['int', ['char *']]);
    registerController();
    var app = $.NSApplication.sharedApplication;
    app.setActivationPolicy($.NSApplicationActivationPolicyRegular);
    var style = $.NSWindowStyleMaskTitled | $.NSWindowStyleMaskClosable |
        $.NSWindowStyleMaskMiniaturizable | $.NSWindowStyleMaskResizable;
    ui.window = $.NSWindow.alloc.initWithContentRectStyleMaskBackingDefer(
        $.NSMakeRect(0, 0, 760, 500), style, $.NSBackingStoreBuffered, false);
    ui.window.title = $('kasholkaTTS');
    ui.window.contentMinSize = $.NSMakeSize(680, 400);
    ui.window.releasedWhenClosed = false;
    ui.window.delegate = controller;
    ui.content = ui.window.contentView;

    ui.voiceLabel = addLabel('Голос', 13, false);
    ui.voice = $.NSPopUpButton.alloc.initWithFramePullsDown($.NSMakeRect(0, 0, 500, 32), false);
    ui.voice.target = controller;
    ui.voice.action = 'voice:';
    ui.content.addSubview(ui.voice);
    ui.refresh = addButton('Обновить', 'refresh:');
    ui.rateLabel = addLabel('Скорость', 13, false);
    ui.rate = addSlider(0, 1, clamp(unwrap(defaults.objectForKey($('speedPosition')), 0.5), 0, 1, 0.5),
        'rate:');
    ui.rate.toolTip = $('Слева медленнее, справа быстрее. Посередине — обычный темп. Применяется при новом чтении.');
    ui.rateValue = addLabel('', 13, true);
    ui.textLabel = addLabel('ВАШ ТЕКСТ', 12, true);
    ui.open = addButton('Открыть .txt…', 'openText:');

    var scroll = $.NSScrollView.alloc.initWithFrame($.NSMakeRect(16, 92, 728, 280));
    ui.scroll = scroll;
    scroll.borderType = $.NSBezelBorder;
    scroll.hasVerticalScroller = true;
    ui.editor = $.NSTextView.alloc.initWithFrame($.NSMakeRect(0, 0, 820, 282));
    ui.editor.richText = false;
    ui.editor.allowsUndo = true;
    ui.editor.font = $.NSFont.systemFontOfSize(18);
    ui.editor.textColor = $.NSColor.textColor;
    ui.editor.backgroundColor = $.NSColor.textBackgroundColor;
    ui.editor.textContainerInset = $.NSMakeSize(16, 16);
    ui.editor.verticallyResizable = true;
    ui.editor.horizontallyResizable = false;
    ui.editor.minSize = $.NSMakeSize(0, 0);
    ui.editor.maxSize = $.NSMakeSize(1000000, 1000000);
    ui.editor.autoresizingMask = $.NSViewWidthSizable;
    ui.editor.textContainer.containerSize = $.NSMakeSize(820, 1000000);
    ui.editor.textContainer.widthTracksTextView = true;
    scroll.documentView = ui.editor;
    ui.content.addSubview(scroll);

    ui.play = addButton('Читать', 'play:');
    ui.pause = addButton('Пауза', 'pause:');
    ui.stop = addButton('Стоп', 'stop:');
    ui.reset = addButton('Сброс параметров', 'reset:');
    ui.status = addLabel('Загрузка голосов…', 13, false);
    installMenus();
    setScale(clamp(unwrap(defaults.objectForKey($('uiScale')), 1), 0.8, 1.5, 1));
    refreshVoices();
    ui.window.center;
    ui.window.makeKeyAndOrderFront(null);
    ui.window.makeFirstResponder(ui.editor);
    app.activateIgnoringOtherApps(true);
}

function reopen() {
    if (ui.window) ui.window.makeKeyAndOrderFront(null);
}

function idle() { return 30; }

function quit() {
    if (about.player) about.player.pause;
    stopSynth();
    closeHosts();
}

function terminateApp() {
    quit();
    $.NSApplication.sharedApplication.terminate(null);
}

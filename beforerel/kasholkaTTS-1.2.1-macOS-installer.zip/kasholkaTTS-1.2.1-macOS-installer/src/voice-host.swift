// Interpreted by Apple's swift-frontend. Swift 5.5 / macOS Monterey APIs only.
// Same JSON protocol as voice-host.js; no shell evaluation of speech text.
import Foundation
import AVFoundation

enum HostError: Error, CustomStringConvertible {
    case message(String)
    var description: String {
        switch self { case .message(let text): return text }
    }
}

struct SpeechRequest: Decodable {
    let id: String
    let text: String
    let factor: Double
}

struct HostControl: Decodable {
    let command: String
    let time: Double
}

final class SpeechSession: NSObject, AVSpeechSynthesizerDelegate {
    let directory: URL
    let synthesizer = AVSpeechSynthesizer()
    var started = false
    var finished = false
    var cancelled = false
    var lastState = ""

    init(directory: URL) {
        self.directory = directory
        super.init()
        synthesizer.delegate = self
    }

    func report(_ value: [String: Any]) throws {
        let data = try JSONSerialization.data(withJSONObject: value)
        try data.write(to: directory.appendingPathComponent("result.json"), options: .atomic)
    }

    func read<T: Decodable>(_ name: String, as type: T.Type) throws -> T {
        let data = try Data(contentsOf: directory.appendingPathComponent(name + ".json"))
        return try JSONDecoder().decode(type, from: data)
    }

    func listVoices() throws {
        let voices = AVSpeechSynthesisVoice.speechVoices().map {
            ["id": $0.identifier, "name": $0.name, "locale": $0.language]
        }
        try report(["state": "voices", "voices": voices])
    }

    func speak() throws {
        defer {
            synthesizer.delegate = nil
            synthesizer.stopSpeaking(at: .immediate)
        }
        let request = try read("request", as: SpeechRequest.self)
        guard !request.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw HostError.message("Нет текста для чтения.")
        }
        guard let voice = AVSpeechSynthesisVoice(identifier: request.id) else {
            throw HostError.message("Swift не получил выбранный голос. Обновите список.")
        }
        let utterance = AVSpeechUtterance(string: request.text)
        utterance.voice = voice
        let factor = request.factor.isFinite ? min(2, max(0.5, request.factor)) : 1
        utterance.rate = min(AVSpeechUtteranceMaximumSpeechRate,
            max(AVSpeechUtteranceMinimumSpeechRate, utterance.rate * Float(factor)))
        let deadline = Date().addingTimeInterval(15)
        try checkLease()
        synthesizer.speak(utterance)
        while !finished {
            let control = try checkLease()
            if started && control.command == "pause" && !synthesizer.isPaused {
                synthesizer.pauseSpeaking(at: .immediate)
            } else if control.command == "play" && synthesizer.isPaused {
                synthesizer.continueSpeaking()
            }
            if started {
                let state = synthesizer.isPaused ? "paused" : "speaking"
                if state != lastState {
                    try report(["state": state])
                    lastState = state
                }
            } else if Date() > deadline {
                throw HostError.message("Голос не начал чтение за 15 секунд.")
            }
            RunLoop.current.run(until: Date().addingTimeInterval(0.05))
        }
        if cancelled { throw HostError.message("Система прервала чтение.") }
        try report(["state": "finished"])
    }

    @discardableResult
    func checkLease() throws -> HostControl {
        let control = try read("control", as: HostControl.self)
        guard control.time.isFinite, Date().timeIntervalSince1970 * 1000 - control.time <= 15000 else {
            throw HostError.message("Приложение больше не отвечает.")
        }
        return control
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didStart utterance: AVSpeechUtterance) {
        started = true
    }
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        finished = true
    }
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        cancelled = true
        finished = true
    }
}

guard CommandLine.arguments.count == 3 else { exit(2) }
let mode = CommandLine.arguments[1]
guard mode == "list" || mode == "speak" else { exit(2) }
let session = SpeechSession(directory: URL(fileURLWithPath: CommandLine.arguments[2], isDirectory: true))
do {
    if mode == "list" { try session.listVoices() }
    else { try session.speak() }
} catch {
    try? session.report(["state": "error", "message": String(describing: error)])
    exit(1)
}
